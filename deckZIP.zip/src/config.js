export const defaultConfig = {
    baseAPIUrl:"http://localhost:5001",
}