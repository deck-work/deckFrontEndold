import './App.css';
import { RenderRout } from './Router';
import Header from './component/header';
import Login from './login';

import Upload from './upload';
// import Profile from './profile';


function App() {

  return (<>
  <RenderRout>
    {/* <Login /> */}
  </RenderRout>
    
</>
   
    
  );
}

export default App;
