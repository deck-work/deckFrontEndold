import Login from "../../../login";

function Header (){
    return (
        <>
        <div className="header">
            <h3> DECK</h3>
        {/* <Login></Login> */}
        </div>
        </>
    )
}
export default Header;