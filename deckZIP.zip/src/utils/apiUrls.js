// export const apiUrls = {

  
//   UPLOADFILE: "/uploadFile",
//   GETFILE:"/getDeck",
//   CONVERT:"/converttoimage",
//   REGISTER:"/register",
//   GETPPTDATA:"/pptData",
//   GETSUMMARY:"/getSummary",
//   GETSLIDESTEXT:"/getSlidesText",
//   CREATESLIDETEXT:"/createSummary",
//   GETSLIDESID:"/getSlideId"
  
// };
export const apiUrls = {

  
  UPLOADFILE: "/uploadFile",
  GETFILE:"/deck/listAll",
  CONVERT:"/deck/converttoimage",
  REGISTER:"/register",
  GETPPTDATA:"/deck/dataById",
  GETSUMMARY:"/deck/getSummary",
  GETSLIDESTEXT:"/deck/slideDataById",
  CREATESLIDETEXT:"/createSummary",
  GETSLIDESID:"/getSlideId"
  
};